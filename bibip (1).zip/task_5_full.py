import os
import json
from datetime import datetime
from decimal import Decimal
from typing import Dict, List, Optional, Tuple
from collections import defaultdict
import bisect

from models import Car, CarFullInfo, CarStatus, Model, ModelSaleStats, Sale


class CarService:
    def __init__(self, root_directory_path: str) -> None:
        self.root_directory_path = root_directory_path
        self._ensure_directories()
        
        # Загружаем индексы в память (они должны быть отсортированы)
        self.models_index = self._load_sorted_index("models_index.txt")
        self.cars_index = self._load_sorted_index("cars_index.txt")
        self.sales_index = self._load_sorted_index("sales_index.txt")
        self.sales_by_number_index = self._load_sorted_index("sales_by_number_index.txt")
    
    def _ensure_directories(self):
        """Создание необходимых директорий"""
        os.makedirs(self.root_directory_path, exist_ok=True)
    
    def _load_sorted_index(self, filename: str) -> List[Tuple[str, int]]:
        """Загрузка отсортированного индекса из файла"""
        index_path = os.path.join(self.root_directory_path, filename)
        index = []
        
        if os.path.exists(index_path):
            with open(index_path, 'r') as f:
                for line in f:
                    line = line.strip()
                    if line:
                        parts = line.split(';')
                        if len(parts) >= 2:
                            key = parts[0]
                            try:
                                line_num = int(parts[1])
                                index.append((key, line_num))
                            except ValueError:
                                continue
        
        # Сортируем индекс по ключу
        index.sort(key=lambda x: x[0])
        return index
    
    def _save_sorted_index(self, filename: str, index: List[Tuple[str, int]]):
        """Сохранение отсортированного индекса в файл"""
        index_path = os.path.join(self.root_directory_path, filename)
        
        # Сортируем перед сохранением
        index.sort(key=lambda x: x[0])
        
        with open(index_path, 'w') as f:
            for key, line_num in index:
                f.write(f"{key};{line_num}\n")
    
    def _find_in_index(self, index: List[Tuple[str, int]], key: str) -> Optional[int]:
        """Поиск ключа в отсортированном индексе (бинарный поиск)"""
        # Используем бинарный поиск для отсортированного списка
        idx = bisect.bisect_left([item[0] for item in index], key)
        if idx < len(index) and index[idx][0] == key:
            return index[idx][1]
        return None
    
    def _insert_into_index(self, index: List[Tuple[str, int]], key: str, line_num: int):
        """Вставка новой записи в отсортированный индекс"""
        # Находим позицию для вставки
        idx = bisect.bisect_left([item[0] for item in index], key)
        
        # Проверяем, не существует ли уже такой ключ
        if idx < len(index) and index[idx][0] == key:
            # Обновляем существующую запись
            index[idx] = (key, line_num)
        else:
            # Вставляем новую запись
            index.insert(idx, (key, line_num))
    
    def _remove_from_index(self, index: List[Tuple[str, int]], key: str) -> bool:
        """Удаление записи из отсортированного индекса"""
        # Находим позицию для удаления
        idx = bisect.bisect_left([item[0] for item in index], key)
        
        if idx < len(index) and index[idx][0] == key:
            # Удаляем запись
            index.pop(idx)
            return True
        return False
    
    def _format_line(self, data: dict) -> str:
        """Форматирование строки для записи в файл"""
        # Конвертируем все значения в строки
        formatted = {}
        for key, value in data.items():
            if isinstance(value, datetime):
                formatted[key] = value.isoformat()
            elif isinstance(value, Decimal):
                formatted[key] = str(value)
            elif value is None:
                formatted[key] = ""
            else:
                formatted[key] = str(value)
        
        line = json.dumps(formatted, ensure_ascii=False)
        # Дополняем строку до 500 символов и добавляем \n
        return line.ljust(500) + '\n'
    
    def _append_to_data_file(self, file_path: str, data: dict) -> int:
        """Добавление записи в файл данных и возврат номера строки"""
        line = self._format_line(data)
        
        with open(file_path, 'a') as f:
            # Получаем текущую позицию (это будет номер строки)
            f.seek(0, 2)  # Перемещаемся в конец файла
            current_pos = f.tell()
            line_num = current_pos // 501 if current_pos > 0 else 0
            f.write(line)
            
        return line_num
    
    def _read_line(self, file_path: str, line_num: int) -> Optional[dict]:
        """Чтение строки из файла"""
        try:
            with open(file_path, 'r') as f:
                f.seek(line_num * 501)  # 500 символов + \n
                line = f.read(500).strip()
                if line:
                    return json.loads(line)
        except (FileNotFoundError, json.JSONDecodeError, IndexError):
            pass
        return None
    
    def _write_line(self, file_path: str, line_num: int, data: dict):
        """Запись строки в файл"""
        line = self._format_line(data)
        
        with open(file_path, 'r+') as f:
            f.seek(line_num * 501)
            f.write(line)
    
    def _check_model_exists(self, model_id: int) -> bool:
        """Проверка существования модели по ID"""
        return self._find_in_index(self.models_index, str(model_id)) is not None

    # Задание 1. Сохранение автомобилей и моделей
    def add_model(self, model: Model) -> Model:
        """Добавление модели автомобиля"""
        # Пути к файлам
        models_data_path = os.path.join(self.root_directory_path, "models.txt")
        
        # Проверяем, существует ли модель с таким id
        if self._check_model_exists(model.id):
            raise ValueError(f"Model with id {model.id} already exists")
        
        # Добавляем запись в файл данных
        line_num = self._append_to_data_file(models_data_path, model.model_dump())
        
        # Вставляем в отсортированный индекс в памяти
        self._insert_into_index(self.models_index, str(model.id), line_num)
        
        # Сохраняем обновленный индекс в файл
        self._save_sorted_index("models_index.txt", self.models_index)
        
        return model
    
    # Задание 1. Сохранение автомобилей и моделей
    def add_car(self, car: Car) -> Car:
        """Добавление автомобиля"""
        # Пути к файлам
        cars_data_path = os.path.join(self.root_directory_path, "cars.txt")
        
        # Проверяем, существует ли автомобиль с таким VIN
        if self._find_in_index(self.cars_index, car.vin) is not None:
            raise ValueError(f"Car with VIN {car.vin} already exists")
        
        # Проверяем, существует ли модель
        if not self._check_model_exists(car.model):
            raise ValueError(f"Model with id {car.model} not found")
        
        # Добавляем запись в файл данных
        line_num = self._append_to_data_file(cars_data_path, car.model_dump())
        
        # Вставляем в отсортированный индекс в памяти
        self._insert_into_index(self.cars_index, car.vin, line_num)
        
        # Сохраняем обновленный индекс в файл
        self._save_sorted_index("cars_index.txt", self.cars_index)
        
        return car

    # Задание 2. Сохранение продаж.
    def sell_car(self, sale: Sale) -> Car:
        """Продажа автомобиля"""
        car_path = os.path.join(self.root_directory_path, "cars.txt")
        sales_path = os.path.join(self.root_directory_path, "sales.txt")
        
        # Проверяем существование автомобиля
        car_line_num = self._find_in_index(self.cars_index, sale.car_vin)
        if car_line_num is None:
            raise ValueError(f"Car with VIN {sale.car_vin} not found")
        
        # Читаем данные автомобиля
        car_data = self._read_line(car_path, car_line_num)
        if not car_data:
            raise ValueError(f"Car data for VIN {sale.car_vin} not found")
        
        # Создаем объект Car
        car = Car(
            vin=car_data['vin'],
            model=int(car_data['model']),
            price=Decimal(car_data['price']),
            date_start=datetime.fromisoformat(car_data['date_start']),
            status=CarStatus(car_data['status'])
        )
        
        # Проверяем, доступен ли автомобиль для продажи
        if car.status != CarStatus.available:
            raise ValueError(f"Cannot sell car with status {car.status}")
        
        # Обновляем статус автомобиля на 'sold'
        car.status = CarStatus.sold
        
        # Сохраняем обновленные данные автомобиля
        self._write_line(car_path, car_line_num, car.model_dump())
        
        # Добавляем запись о продаже в файл данных
        sale_line_num = self._append_to_data_file(sales_path, sale.model_dump())
        
        # Вставляем в отсортированные индексы продаж
        self._insert_into_index(self.sales_index, sale.car_vin, sale_line_num)
        self._insert_into_index(self.sales_by_number_index, sale.sales_number, sale_line_num)
        
        # Сохраняем обновленные индексы в файлы
        self._save_sorted_index("sales_index.txt", self.sales_index)
        self._save_sorted_index("sales_by_number_index.txt", self.sales_by_number_index)
        
        return car
    
    # Задание 3. Доступные к продаже
    def get_cars(self, status: CarStatus) -> list[Car]:
        """Получение списка автомобилей по статусу"""
        car_path = os.path.join(self.root_directory_path, "cars.txt")
        cars = []
        
        if not os.path.exists(car_path):
            return cars
        
        # Читаем все строки файла
        with open(car_path, 'r') as f:
            line_num = 0
            while True:
                try:
                    f.seek(line_num * 501)
                    line = f.read(500).strip()
                    
                    if not line:
                        break
                    
                    car_data = json.loads(line)
                    
                    # Преобразуем данные
                    car_status = CarStatus(car_data['status'])
                    
                    if car_status == status:
                        car = Car(
                            vin=car_data['vin'],
                            model=int(car_data['model']),
                            price=Decimal(car_data['price']),
                            date_start=datetime.fromisoformat(car_data['date_start']),
                            status=car_status
                        )
                        cars.append(car)
                    
                    line_num += 1
                except (json.JSONDecodeError, UnicodeDecodeError):
                    break
        
        # Сортируем автомобили по VIN-коду
        cars.sort(key=lambda car: car.vin)
        
        return cars

    # Задание 4. Детальная информация
    def get_car_info(self, vin: str) -> CarFullInfo | None:
        """Получение детальной информации об автомобиле"""
        car_path = os.path.join(self.root_directory_path, "cars.txt")
        model_path = os.path.join(self.root_directory_path, "models.txt")
        sales_path = os.path.join(self.root_directory_path, "sales.txt")
        
        # Проверяем существование автомобиля
        car_line_num = self._find_in_index(self.cars_index, vin)
        if car_line_num is None:
            return None
        
        # Читаем данные автомобиля
        car_data = self._read_line(car_path, car_line_num)
        if not car_data:
            return None
        
        # Читаем данные модели
        model_id = str(car_data['model'])
        model_line_num = self._find_in_index(self.models_index, model_id)
        if model_line_num is None:
            return None
        
        model_data = self._read_line(model_path, model_line_num)
        if not model_data:
            return None
        
        # Читаем данные о продаже (если есть)
        sales_data = None
        sale_line_num = self._find_in_index(self.sales_index, vin)
        if sale_line_num is not None:
            sales_data = self._read_line(sales_path, sale_line_num)
        
        # Создаем объект CarFullInfo
        return CarFullInfo(
            vin=car_data['vin'],
            car_model_name=model_data['name'],
            car_model_brand=model_data['brand'],
            price=Decimal(car_data['price']),
            date_start=datetime.fromisoformat(car_data['date_start']),
            status=CarStatus(car_data['status']),
            sales_date=datetime.fromisoformat(sales_data['sales_date']) if sales_data and sales_data.get('sales_date') else None,
            sales_cost=Decimal(sales_data['cost']) if sales_data and sales_data.get('cost') else None
        )
    
    # ЗАДАНИЕ 5. Обновление ключевого поля
    def update_vin(self, vin: str, new_vin: str) -> Car:
        """
        Обновление VIN-кода автомобиля.
        
        Алгоритм:
        1. Найти автомобиль по старому VIN через индекс
        2. Проверить, что новый VIN не существует
        3. Обновить VIN в данных автомобиля
        4. Обновить запись в файле cars.txt
        5. Перестроить индекс (удалить старый VIN, добавить новый)
        6. Обновить VIN в записи о продаже (если есть)
        
        Возвращает обновленный объект Car.
        """
        print(f"\n=== Обновление VIN-кода ===")
        print(f"Старый VIN: {vin}")
        print(f"Новый VIN: {new_vin}")
        
        car_path = os.path.join(self.root_directory_path, "cars.txt")
        sales_path = os.path.join(self.root_directory_path, "sales.txt")
        
        # 1. Прочитать данные об автомобиле по старому VIN
        print("1. Ищем автомобиль по старому VIN в индексе cars_index.txt")
        car_line_num = self._find_in_index(self.cars_index, vin)
        
        if car_line_num is None:
            raise ValueError(f"Автомобиль с VIN {vin} не найден")
        
        print(f"   Автомобиль найден в строке: {car_line_num}")
        
        # Читаем данные автомобиля из файла cars.txt
        car_data = self._read_line(car_path, car_line_num)
        if not car_data:
            raise ValueError(f"Не удалось прочитать данные автомобиля с VIN {vin}")
        
        print(f"   Данные автомобиля прочитаны:")
        print(f"     Текущий VIN: {car_data['vin']}")
        print(f"     Модель: {car_data['model']}")
        print(f"     Статус: {car_data['status']}")
        
        # 2. Проверить, что новый VIN не существует
        print(f"\n2. Проверяем, что новый VIN {new_vin} не существует в базе")
        if self._find_in_index(self.cars_index, new_vin) is not None:
            raise ValueError(f"Автомобиль с VIN {new_vin} уже существует в базе")
        
        print(f"   Новый VIN свободен, можно обновлять")
        
        # 3. Обновить VIN в данных автомобиля
        print(f"\n3. Обновляем VIN в данных автомобиля")
        old_vin = car_data['vin']
        car_data['vin'] = new_vin
        
        # 4. Записать обновленный объект в файл cars.txt по тому же номеру строки
        print(f"4. Записываем обновленные данные в файл cars.txt (строка {car_line_num})")
        self._write_line(car_path, car_line_num, car_data)
        print(f"   Данные автомобиля обновлены в файле")
        
        # 5. Перестроить индекс автомобилей
        print(f"\n5. Перестраиваем индекс автомобилей (cars_index.txt)")
        
        # Удаляем старый VIN из индекса в памяти
        self._remove_from_index(self.cars_index, old_vin)
        print(f"   Старый VIN '{old_vin}' удален из индекса в памяти")
        
        # Добавляем новый VIN в индекс в памяти
        self._insert_into_index(self.cars_index, new_vin, car_line_num)
        print(f"   Новый VIN '{new_vin}' добавлен в индекс в памяти (строка {car_line_num})")
        
        # Сохраняем обновленный индекс в файл
        self._save_sorted_index("cars_index.txt", self.cars_index)
        print(f"   Индекс сохранен в файл cars_index.txt")
        
        # 6. Обновить VIN в записи о продаже (если автомобиль был продан)
        print(f"\n6. Проверяем, есть ли продажа для этого автомобиля")
        sale_line_num = self._find_in_index(self.sales_index, old_vin)
        
        if sale_line_num is not None:
            print(f"   Найдена продажа в строке: {sale_line_num}")
            
            # Читаем данные о продаже
            sales_data = self._read_line(sales_path, sale_line_num)
            if sales_data:
                print(f"   Данные о продаже прочитаны:")
                print(f"     Старый VIN в продаже: {sales_data.get('car_vin')}")
                
                # Обновляем VIN в данных о продаже
                sales_data['car_vin'] = new_vin
                
                # Записываем обновленные данные о продаже
                self._write_line(sales_path, sale_line_num, sales_data)
                print(f"   VIN в данных о продаже обновлен на '{new_vin}'")
                
                # Обновляем индекс продаж
                print(f"   Обновляем индекс продаж (sales_index.txt)")
                
                # Удаляем старый VIN из индекса продаж
                self._remove_from_index(self.sales_index, old_vin)
                print(f"     Старый VIN '{old_vin}' удален из индекса продаж")
                
                # Добавляем новый VIN в индекс продаж
                self._insert_into_index(self.sales_index, new_vin, sale_line_num)
                print(f"     Новый VIN '{new_vin}' добавлен в индекс продаж")
                
                # Сохраняем обновленный индекс продаж
                self._save_sorted_index("sales_index.txt", self.sales_index)
                print(f"     Индекс продаж сохранен в файл sales_index.txt")
            else:
                print(f"   Не удалось прочитать данные о продаже")
        else:
            print(f"   Продажа для этого автомобиля не найдена")
        
        # Создаем и возвращаем обновленный объект Car
        print(f"\n7. Создаем обновленный объект Car")
        updated_car = Car(
            vin=new_vin,
            model=int(car_data['model']),
            price=Decimal(car_data['price']),
            date_start=datetime.fromisoformat(car_data['date_start']),
            status=CarStatus(car_data['status'])
        )
        
        print(f"   Объект Car успешно создан с новым VIN: {updated_car.vin}")
        print(f"=== Обновление VIN завершено успешно ===")
        
        return updated_car

    # Задание 6. Удаление продажи
    def revert_sale(self, sales_number: str) -> Car:
        """Отмена продажи автомобиля"""
        car_path = os.path.join(self.root_directory_path, "cars.txt")
        sales_path = os.path.join(self.root_directory_path, "sales.txt")
        
        # Проверяем существование продажи
        sale_line_num = self._find_in_index(self.sales_by_number_index, sales_number)
        if sale_line_num is None:
            raise ValueError(f"Sale with number {sales_number} not found")
        
        # Читаем данные продажи
        sales_data = self._read_line(sales_path, sale_line_num)
        if not sales_data:
            raise ValueError(f"Sale data for number {sales_number} not found")
        
        vin = sales_data['car_vin']
        
        # Проверяем существование автомобиля
        car_line_num = self._find_in_index(self.cars_index, vin)
        if car_line_num is None:
            raise ValueError(f"Car with VIN {vin} not found")
        
        # Читаем данные автомобиля
        car_data = self._read_line(car_path, car_line_num)
        if not car_data:
            raise ValueError(f"Car data for VIN {vin} not found")
        
        # Обновляем статус автомобиля
        car_data['status'] = CarStatus.available.value
        
        # Обновляем запись автомобиля
        self._write_line(car_path, car_line_num, car_data)
        
        # Удаляем запись о продаже (записываем пустую строку)
        with open(sales_path, 'r+') as f:
            f.seek(sale_line_num * 501)
            f.write(' ' * 500 + '\n')
        
        # Удаляем из индексов продаж
        self._remove_from_index(self.sales_index, vin)
        self._remove_from_index(self.sales_by_number_index, sales_number)
        
        # Сохраняем обновленные индексы
        self._save_sorted_index("sales_index.txt", self.sales_index)
        self._save_sorted_index("sales_by_number_index.txt", self.sales_by_number_index)
        
        # Создаем объект Car для возврата
        return Car(
            vin=car_data['vin'],
            model=int(car_data['model']),
            price=Decimal(car_data['price']),
            date_start=datetime.fromisoformat(car_data['date_start']),
            status=CarStatus(car_data['status'])
        )

    # Задание 7. Самые продаваемые модели
    def top_models_by_sales(self) -> list[ModelSaleStats]:
        """Получение статистики по продажам моделей"""
        sales_path = os.path.join(self.root_directory_path, "sales.txt")
        car_path = os.path.join(self.root_directory_path, "cars.txt")
        model_path = os.path.join(self.root_directory_path, "models.txt")
        
        if not os.path.exists(sales_path):
            return []
        
        # Собираем статистику продаж
        sales_stats = defaultdict(int)
        model_info = {}  # model_id -> (name, brand)
        
        # Сначала собираем информацию о моделях
        with open(model_path, 'r') as f:
            line_num = 0
            while True:
                try:
                    f.seek(line_num * 501)
                    line = f.read(500).strip()
                    
                    if not line:
                        break
                    
                    model_data = json.loads(line)
                    model_info[model_data['id']] = (model_data['name'], model_data['brand'])
                    line_num += 1
                except (json.JSONDecodeError, UnicodeDecodeError):
                    break
        
        # Теперь обрабатываем продажи (используем индекс для поиска автомобилей)
        with open(sales_path, 'r') as f:
            line_num = 0
            while True:
                try:
                    f.seek(line_num * 501)
                    line = f.read(500).strip()
                    
                    if not line:
                        break
                    
                    # Пропускаем пустые строки (удаленные продажи)
                    if not line or line.isspace():
                        line_num += 1
                        continue
                    
                    sales_data = json.loads(line)
                    vin = sales_data['car_vin']
                    
                    # Используем индекс для поиска автомобиля
                    car_line_num = self._find_in_index(self.cars_index, vin)
                    if car_line_num is not None:
                        car_data = self._read_line(car_path, car_line_num)
                        if car_data:
                            model_id = car_data['model']
                            sales_stats[model_id] += 1
                    
                    line_num += 1
                except (json.JSONDecodeError, UnicodeDecodeError):
                    break
        
        # Создаем список статистики
        result = []
        for model_id, count in sorted(sales_stats.items(), key=lambda x: x[1], reverse=True):
            if model_id in model_info:
                name, brand = model_info[model_id]
                result.append(ModelSaleStats(
                    car_model_name=name,
                    brand=brand,
                    sales_number=count
                ))
        
        return result