# Задание 2. Сохранение продаж (исправленная версия)
def sell_car(self, sale: Sale) -> Car:
    """
    Продажа автомобиля.
    
    Алгоритм:
    1. Записать продажу в sales.txt и добавить в sales_index.txt
    2. Найти автомобиль в cars.txt через индекс
    3. Обновить статус автомобиля на 'sold' (можно продавать available и reserve)
    4. Записать обновленный автомобиль в cars.txt
    """
    print(f"\n=== Начало продажи автомобиля ===")
    print(f"VIN: {sale.car_vin}")
    print(f"Номер продажи: {sale.sales_number}")
    
    # 1. Записываем продажу в файл sales.txt
    sales_data_path = os.path.join(self.root_directory_path, "sales.txt")
    print(f"1. Записываем продажу в файл: {sales_data_path}")
    
    # Добавляем запись о продаже в конец файла
    sale_line_num = self._append_to_data_file(sales_data_path, sale.model_dump())
    print(f"   Продажа записана в строку: {sale_line_num}")
    
    # 2. Добавляем запись в индекс продаж (sales_index.txt)
    print(f"2. Обновляем индекс продаж (sales_index.txt)")
    
    # Вставляем в отсортированный индекс продаж
    self._insert_into_index(self.sales_index, sale.car_vin, sale_line_num)
    
    # Сохраняем обновленный индекс в файл
    self._save_sorted_index("sales_index.txt", self.sales_index)
    print(f"   Индекс продаж обновлен: {sale.car_vin} -> строка {sale_line_num}")
    
    # 3. Находим автомобиль в файле cars.txt через индекс
    print(f"3. Ищем автомобиль в индексе автомобилей")
    car_line_num = self._find_in_index(self.cars_index, sale.car_vin)
    
    if car_line_num is None:
        raise ValueError(f"Автомобиль с VIN {sale.car_vin} не найден в базе")
    
    print(f"   Автомобиль найден в строке: {car_line_num}")
    
    # 4. Читаем данные автомобиля из файла cars.txt
    cars_data_path = os.path.join(self.root_directory_path, "cars.txt")
    print(f"4. Читаем данные автомобиля из файла: {cars_data_path}")
    
    car_data = self._read_line(cars_data_path, car_line_num)
    if not car_data:
        raise ValueError(f"Не удалось прочитать данные автомобиля с VIN {sale.car_vin}")
    
    print(f"   Данные автомобиля прочитаны: {car_data['vin']}, статус: {car_data['status']}")
    
    # 5. Создаем объект Car и проверяем, можно ли его продать
    car = Car(
        vin=car_data['vin'],
        model=int(car_data['model']),
        price=Decimal(car_data['price']),
        date_start=datetime.fromisoformat(car_data['date_start']),
        status=CarStatus(car_data['status'])
    )
    
    # ИСПРАВЛЕНИЕ: Проверяем, что автомобиль можно продать (available или reserve)
    if car.status not in [CarStatus.available, CarStatus.reserve]:
        raise ValueError(f"Нельзя продать автомобиль со статусом {car.status}")
    
    # 6. Обновляем статус автомобиля на 'sold'
    print(f"5. Обновляем статус автомобиля с '{car.status}' на 'sold'")
    car.status = CarStatus.sold
    
    # 7. Записываем обновленный автомобиль обратно в файл cars.txt
    print(f"6. Записываем обновленные данные автомобиля в файл")
    self._write_line(cars_data_path, car_line_num, car.model_dump())
    print(f"   Данные автомобиля обновлены в строке: {car_line_num}")
    
    print(f"=== Продажа успешно завершена ===")
    return car




# Задание 7. Самые продаваемые модели (исправленная версия)
def top_models_by_sales(self) -> list[ModelSaleStats]:
    """
    Получение топ-3 самых продаваемых моделей.
    
    Алгоритм:
    1. Собрать статистику продаж по ID моделей
    2. Отсортировать модели по количеству продаж (убыванию)
    3. При равенстве продаж сортировать по средней цене модели (убыванию)
    4. Взять топ-3 модели
    5. Получить информацию о каждой модели
    6. Вернуть список ModelSaleStats
    
    Возвращает список из 3 самых продаваемых моделей.
    """
    print(f"\n=== Определение самых продаваемых моделей ===")
    
    sales_path = os.path.join(self.root_directory_path, "sales.txt")
    car_path = os.path.join(self.root_directory_path, "cars.txt")
    model_path = os.path.join(self.root_directory_path, "models.txt")
    
    if not os.path.exists(sales_path):
        print("Файл продаж не найден. Нет данных для анализа.")
        return []
    
    # 1. Завести словарь для статистики продаж
    print("1. Собираем статистику продаж по ID моделей")
    
    # Словарь: model_id -> количество продаж
    sales_stats = defaultdict(int)
    # Словарь: model_id -> (название, бренд, средняя цена автомобиля)
    model_info = {}  # model_id -> (name, brand, avg_price)
    
    # Сначала собираем информацию о моделях
    print("   Читаем информацию о моделях...")
    with open(model_path, 'r') as f:
        line_num = 0
        while True:
            try:
                f.seek(line_num * 501)
                line = f.read(500).strip()
                
                if not line:
                    break
                
                model_data = json.loads(line)
                model_id = model_data['id']
                model_info[model_id] = {
                    'name': model_data['name'],
                    'brand': model_data['brand'],
                    'total_price': Decimal('0'),
                    'car_count': 0
                }
                line_num += 1
            except (json.JSONDecodeError, UnicodeDecodeError, KeyError):
                line_num += 1
                continue
    
    # Собираем информацию о ценах автомобилей для каждой модели
    print("   Анализируем цены автомобилей по моделям...")
    with open(car_path, 'r') as f:
        line_num = 0
        while True:
            try:
                f.seek(line_num * 501)
                line = f.read(500).strip()
                
                if not line:
                    break
                
                car_data = json.loads(line)
                model_id = car_data['model']
                
                if model_id in model_info:
                    try:
                        price = Decimal(car_data['price'])
                        model_info[model_id]['total_price'] += price
                        model_info[model_id]['car_count'] += 1
                    except (KeyError, ValueError):
                        pass
                
                line_num += 1
            except (json.JSONDecodeError, UnicodeDecodeError):
                line_num += 1
                continue
    
    # Вычисляем средние цены
    for model_id, info in model_info.items():
        if info['car_count'] > 0:
            info['avg_price'] = info['total_price'] / info['car_count']
        else:
            info['avg_price'] = Decimal('0')
    
    # 2. Прочитать файл sales.txt построчно
    print("2. Анализируем продажи...")
    total_sales = 0
    
    with open(sales_path, 'r') as f:
        line_num = 0
        while True:
            try:
                f.seek(line_num * 501)
                line = f.read(500).strip()
                
                if not line:
                    break
                
                # Пропускаем пустые строки (удаленные продажи)
                if not line or line.isspace():
                    line_num += 1
                    continue
                
                total_sales += 1
                
                try:
                    sales_data = json.loads(line)
                    vin = sales_data['car_vin']
                    
                    # Используем индекс для быстрого поиска автомобиля
                    car_line_num = self._find_in_index(self.cars_index, vin)
                    if car_line_num is not None:
                        car_data = self._read_line(car_path, car_line_num)
                        if car_data:
                            model_id = car_data['model']
                            sales_stats[model_id] += 1
                
                except json.JSONDecodeError:
                    pass
                
                line_num += 1
                
            except (UnicodeDecodeError, IndexError):
                line_num += 1
                continue
    
    print(f"   Всего обработано продаж: {total_sales}")
    print(f"   Уникальных моделей в продажах: {len(sales_stats)}")
    
    # 3. Преобразуем статистику в список для сортировки
    print("3. Подготавливаем данные для сортировки...")
    model_stats_list = []
    
    for model_id, sales_count in sales_stats.items():
        if model_id in model_info:
            avg_price = model_info[model_id]['avg_price']
            
            model_stats_list.append({
                'model_id': model_id,
                'sales_count': sales_count,
                'avg_price': avg_price,
                'name': model_info[model_id]['name'],
                'brand': model_info[model_id]['brand']
            })
    
    # 4. ИСПРАВЛЕНИЕ: Сортировка по количеству продаж (убыванию), 
    #    при равенстве - по средней цене (убыванию)
    print("4. Сортируем модели...")
    
    model_stats_list.sort(key=lambda x: (-x['sales_count'], -x['avg_price']))
    
    # 5. Берем топ-3 модели
    print("5. Выбираем топ-3 модели...")
    top_models = model_stats_list[:3]
    
    # 6. Формируем результат
    print("6. Формируем результат...")
    result = []
    
    for i, model_stat in enumerate(top_models, 1):
        model_sale_stats = ModelSaleStats(
            car_model_name=model_stat['name'],
            brand=model_stat['brand'],
            sales_number=model_stat['sales_count']
        )
        result.append(model_sale_stats)
        
        print(f"   {i}. {model_stat['name']} ({model_stat['brand']}):")
        print(f"      Продаж: {model_stat['sales_count']}")
        print(f"      Средняя цена автомобиля: {model_stat['avg_price']:.2f}")
    
    if len(top_models) < 3:
        print(f"   Всего найдено только {len(top_models)} моделей с продажами")
    
    print(f"=== Анализ завершен ===")
    return result