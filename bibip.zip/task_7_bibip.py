import os
import json
from datetime import datetime
from decimal import Decimal
from typing import Dict, List, Optional, Tuple
from collections import defaultdict
import bisect

from models import Car, CarFullInfo, CarStatus, Model, ModelSaleStats, Sale


class CarService:
    def __init__(self, root_directory_path: str) -> None:
        self.root_directory_path = root_directory_path
        self._ensure_directories()
        
        # Загружаем индексы в память (они должны быть отсортированы)
        self.models_index = self._load_sorted_index("models_index.txt")
        self.cars_index = self._load_sorted_index("cars_index.txt")
        self.sales_index = self._load_sorted_index("sales_index.txt")
        self.sales_by_number_index = self._load_sorted_index("sales_by_number_index.txt")
    
    def _ensure_directories(self):
        """Создание необходимых директорий"""
        os.makedirs(self.root_directory_path, exist_ok=True)
    
    def _load_sorted_index(self, filename: str) -> List[Tuple[str, int]]:
        """Загрузка отсортированного индекса из файла"""
        index_path = os.path.join(self.root_directory_path, filename)
        index = []
        
        if os.path.exists(index_path):
            with open(index_path, 'r') as f:
                for line in f:
                    line = line.strip()
                    if line:
                        parts = line.split(';')
                        if len(parts) >= 2:
                            key = parts[0]
                            try:
                                line_num = int(parts[1])
                                index.append((key, line_num))
                            except ValueError:
                                continue
        
        # Сортируем индекс по ключу
        index.sort(key=lambda x: x[0])
        return index
    
    def _save_sorted_index(self, filename: str, index: List[Tuple[str, int]]):
        """Сохранение отсортированного индекса в файл"""
        index_path = os.path.join(self.root_directory_path, filename)
        
        # Сортируем перед сохранением
        index.sort(key=lambda x: x[0])
        
        with open(index_path, 'w') as f:
            for key, line_num in index:
                f.write(f"{key};{line_num}\n")
    
    def _find_in_index(self, index: List[Tuple[str, int]], key: str) -> Optional[int]:
        """Поиск ключа в отсортированном индексе (бинарный поиск)"""
        # Используем бинарный поиск для отсортированного списка
        idx = bisect.bisect_left([item[0] for item in index], key)
        if idx < len(index) and index[idx][0] == key:
            return index[idx][1]
        return None
    
    def _insert_into_index(self, index: List[Tuple[str, int]], key: str, line_num: int):
        """Вставка новой записи в отсортированный индекс"""
        # Находим позицию для вставки
        idx = bisect.bisect_left([item[0] for item in index], key)
        
        # Проверяем, не существует ли уже такой ключ
        if idx < len(index) and index[idx][0] == key:
            # Обновляем существующую запись
            index[idx] = (key, line_num)
        else:
            # Вставляем новую запись
            index.insert(idx, (key, line_num))
    
    def _remove_from_index(self, index: List[Tuple[str, int]], key: str) -> bool:
        """Удаление записи из отсортированного индекса"""
        # Находим позицию для удаления
        idx = bisect.bisect_left([item[0] for item in index], key)
        
        if idx < len(index) and index[idx][0] == key:
            # Удаляем запись
            index.pop(idx)
            return True
        return False
    
    def _format_line(self, data: dict) -> str:
        """Форматирование строки для записи в файл"""
        # Конвертируем все значения в строки
        formatted = {}
        for key, value in data.items():
            if isinstance(value, datetime):
                formatted[key] = value.isoformat()
            elif isinstance(value, Decimal):
                formatted[key] = str(value)
            elif value is None:
                formatted[key] = ""
            else:
                formatted[key] = str(value)
        
        line = json.dumps(formatted, ensure_ascii=False)
        # Дополняем строку до 500 символов и добавляем \n
        return line.ljust(500) + '\n'
    
    def _read_line(self, file_path: str, line_num: int) -> Optional[dict]:
        """Чтение строки из файла"""
        try:
            with open(file_path, 'r') as f:
                f.seek(line_num * 501)  # 500 символов + \n
                line = f.read(500).strip()
                if line:
                    return json.loads(line)
        except (FileNotFoundError, json.JSONDecodeError, IndexError):
            pass
        return None
    
    def _write_line(self, file_path: str, line_num: int, data: dict):
        """Запись строки в файл"""
        line = self._format_line(data)
        
        with open(file_path, 'r+') as f:
            f.seek(line_num * 501)
            f.write(line)
    
    # ЗАДАНИЕ 7. Самые продаваемые модели
    def top_models_by_sales(self) -> list[ModelSaleStats]:
        """
        Получение топ-3 самых продаваемых моделей.
        
        Алгоритм:
        1. Собрать статистику продаж по ID моделей
        2. Отсортировать модели по количеству продаж (убыванию)
        3. При равенстве продаж сортировать по средней цене модели (убыванию)
        4. Взять топ-3 модели
        5. Получить информацию о каждой модели
        6. Вернуть список ModelSaleStats
        
        Возвращает список из 3 самых продаваемых моделей.
        """
        print(f"\n=== Определение самых продаваемых моделей ===")
        
        sales_path = os.path.join(self.root_directory_path, "sales.txt")
        car_path = os.path.join(self.root_directory_path, "cars.txt")
        model_path = os.path.join(self.root_directory_path, "models.txt")
        
        if not os.path.exists(sales_path):
            print("Файл продаж не найден. Нет данных для анализа.")
            return []
        
        # 1. Завести словарь для статистики продаж
        print("1. Собираем статистику продаж по ID моделей")
        
        # Словарь: model_id -> (количество продаж, общая сумма продаж)
        sales_stats = defaultdict(lambda: [0, Decimal('0')])
        # Словарь: model_id -> (название, бренд, средняя цена автомобиля)
        model_info = {}
        
        # Сначала собираем информацию о моделях и средних ценах
        print("   Читаем информацию о моделях...")
        with open(model_path, 'r') as f:
            line_num = 0
            while True:
                try:
                    f.seek(line_num * 501)
                    line = f.read(500).strip()
                    
                    if not line:
                        break
                    
                    model_data = json.loads(line)
                    model_id = model_data['id']
                    model_info[model_id] = {
                        'name': model_data['name'],
                        'brand': model_data['brand'],
                        'total_price': Decimal('0'),
                        'car_count': 0
                    }
                    line_num += 1
                except (json.JSONDecodeError, UnicodeDecodeError, KeyError):
                    break
        
        # Собираем информацию о ценах автомобилей для каждой модели
        print("   Анализируем цены автомобилей по моделям...")
        with open(car_path, 'r') as f:
            line_num = 0
            while True:
                try:
                    f.seek(line_num * 501)
                    line = f.read(500).strip()
                    
                    if not line:
                        break
                    
                    car_data = json.loads(line)
                    model_id = car_data['model']
                    
                    if model_id in model_info:
                        try:
                            price = Decimal(car_data['price'])
                            model_info[model_id]['total_price'] += price
                            model_info[model_id]['car_count'] += 1
                        except (KeyError, ValueError):
                            pass
                    
                    line_num += 1
                except (json.JSONDecodeError, UnicodeDecodeError):
                    break
        
        # Вычисляем средние цены
        for model_id, info in model_info.items():
            if info['car_count'] > 0:
                info['avg_price'] = info['total_price'] / info['car_count']
            else:
                info['avg_price'] = Decimal('0')
        
        # 2. Прочитать файл sales.txt построчно
        print("2. Анализируем продажи...")
        total_sales = 0
        
        with open(sales_path, 'r') as f:
            line_num = 0
            while True:
                try:
                    f.seek(line_num * 501)
                    line = f.read(500).strip()
                    
                    if not line:
                        break
                    
                    # Пропускаем пустые строки (удаленные продажи)
                    if not line or line.isspace():
                        line_num += 1
                        continue
                    
                    total_sales += 1
                    
                    try:
                        sales_data = json.loads(line)
                        vin = sales_data['car_vin']
                        
                        # Используем индекс для быстрого поиска автомобиля
                        car_line_num = self._find_in_index(self.cars_index, vin)
                        if car_line_num is not None:
                            car_data = self._read_line(car_path, car_line_num)
                            if car_data:
                                model_id = car_data['model']
                                
                                # Инкрементируем количество продаж
                                sales_stats[model_id][0] += 1
                                
                                # Добавляем стоимость продажи
                                try:
                                    cost = Decimal(sales_data['cost'])
                                    sales_stats[model_id][1] += cost
                                except (KeyError, ValueError):
                                    pass
                    
                    except json.JSONDecodeError:
                        pass
                    
                    line_num += 1
                    
                except (UnicodeDecodeError, IndexError):
                    break
        
        print(f"   Всего обработано продаж: {total_sales}")
        print(f"   Уникальных моделей в продажах: {len(sales_stats)}")
        
        # 3. Преобразуем статистику в список для сортировки
        print("3. Подготавливаем данные для сортировки...")
        model_stats_list = []
        
        for model_id, (sales_count, total_cost) in sales_stats.items():
            if model_id in model_info:
                avg_price = model_info[model_id]['avg_price']
                # Вычисляем среднюю стоимость продажи
                avg_sale_price = total_cost / sales_count if sales_count > 0 else Decimal('0')
                
                model_stats_list.append({
                    'model_id': model_id,
                    'sales_count': sales_count,
                    'avg_price': avg_price,
                    'avg_sale_price': avg_sale_price,
                    'name': model_info[model_id]['name'],
                    'brand': model_info[model_id]['brand']
                })
        
        # 4. Сортировка по количеству продаж (убыванию), при равенстве - по средней цене (убыванию)
        print("4. Сортируем модели...")
        
        model_stats_list.sort(key=lambda x: (-x['sales_count'], -x['avg_price']))
        
        # 5. Берем топ-3 модели
        print("5. Выбираем топ-3 модели...")
        top_models = model_stats_list[:3]
        
        # 6. Формируем результат
        print("6. Формируем результат...")
        result = []
        
        for i, model_stat in enumerate(top_models, 1):
            model_sale_stats = ModelSaleStats(
                car_model_name=model_stat['name'],
                brand=model_stat['brand'],
                sales_number=model_stat['sales_count']
            )
            result.append(model_sale_stats)
            
            print(f"   {i}. {model_stat['name']} ({model_stat['brand']}):")
            print(f"      Продаж: {model_stat['sales_count']}")
            print(f"      Средняя цена автомобиля: {model_stat['avg_price']:.2f}")
            print(f"      Средняя цена продажи: {model_stat['avg_sale_price']:.2f}")
        
        if len(top_models) < 3:
            print(f"   Всего найдено только {len(top_models)} моделей с продажами")
        
        print(f"=== Анализ завершен ===")
        return result