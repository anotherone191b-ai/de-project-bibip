import os
import json
from datetime import datetime
from decimal import Decimal
from typing import Dict, List, Optional, Tuple
from collections import defaultdict
import bisect

from models import Car, CarFullInfo, CarStatus, Model, ModelSaleStats, Sale


class CarService:
    def __init__(self, root_directory_path: str) -> None:
        self.root_directory_path = root_directory_path
        self._ensure_directories()
        
        # Загружаем индексы в память (они должны быть отсортированы)
        self.models_index = self._load_sorted_index("models_index.txt")
        self.cars_index = self._load_sorted_index("cars_index.txt")
        self.sales_index = self._load_sorted_index("sales_index.txt")
        self.sales_by_number_index = self._load_sorted_index("sales_by_number_index.txt")
    
    def _ensure_directories(self):
        """Создание необходимых директорий"""
        os.makedirs(self.root_directory_path, exist_ok=True)
    
    def _load_sorted_index(self, filename: str) -> List[Tuple[str, int]]:
        """Загрузка отсортированного индекса из файла"""
        index_path = os.path.join(self.root_directory_path, filename)
        index = []
        
        if os.path.exists(index_path):
            with open(index_path, 'r') as f:
                for line in f:
                    line = line.strip()
                    if line:
                        parts = line.split(';')
                        if len(parts) >= 2:
                            key = parts[0]
                            try:
                                line_num = int(parts[1])
                                index.append((key, line_num))
                            except ValueError:
                                continue
        
        # Сортируем индекс по ключу
        index.sort(key=lambda x: x[0])
        return index
    
    def _save_sorted_index(self, filename: str, index: List[Tuple[str, int]]):
        """Сохранение отсортированного индекса в файл"""
        index_path = os.path.join(self.root_directory_path, filename)
        
        # Сортируем перед сохранением
        index.sort(key=lambda x: x[0])
        
        with open(index_path, 'w') as f:
            for key, line_num in index:
                f.write(f"{key};{line_num}\n")
    
    def _find_in_index(self, index: List[Tuple[str, int]], key: str) -> Optional[int]:
        """Поиск ключа в отсортированном индексе (бинарный поиск)"""
        # Используем бинарный поиск для отсортированного списка
        idx = bisect.bisect_left([item[0] for item in index], key)
        if idx < len(index) and index[idx][0] == key:
            return index[idx][1]
        return None
    
    def _insert_into_index(self, index: List[Tuple[str, int]], key: str, line_num: int):
        """Вставка новой записи в отсортированный индекс"""
        # Находим позицию для вставки
        idx = bisect.bisect_left([item[0] for item in index], key)
        
        # Проверяем, не существует ли уже такой ключ
        if idx < len(index) and index[idx][0] == key:
            # Обновляем существующую запись
            index[idx] = (key, line_num)
        else:
            # Вставляем новую запись
            index.insert(idx, (key, line_num))
    
    def _remove_from_index(self, index: List[Tuple[str, int]], key: str) -> bool:
        """Удаление записи из отсортированного индекса"""
        # Находим позицию для удаления
        idx = bisect.bisect_left([item[0] for item in index], key)
        
        if idx < len(index) and index[idx][0] == key:
            # Удаляем запись
            index.pop(idx)
            return True
        return False
    
    def _format_line(self, data: dict) -> str:
        """Форматирование строки для записи в файл"""
        # Конвертируем все значения в строки
        formatted = {}
        for key, value in data.items():
            if isinstance(value, datetime):
                formatted[key] = value.isoformat()
            elif isinstance(value, Decimal):
                formatted[key] = str(value)
            elif value is None:
                formatted[key] = ""
            else:
                formatted[key] = str(value)
        
        line = json.dumps(formatted, ensure_ascii=False)
        # Дополняем строку до 500 символов и добавляем \n
        return line.ljust(500) + '\n'
    
    def _read_line(self, file_path: str, line_num: int) -> Optional[dict]:
        """Чтение строки из файла"""
        try:
            with open(file_path, 'r') as f:
                f.seek(line_num * 501)  # 500 символов + \n
                line = f.read(500).strip()
                if line:
                    return json.loads(line)
        except (FileNotFoundError, json.JSONDecodeError, IndexError):
            pass
        return None
    
    def _write_line(self, file_path: str, line_num: int, data: dict):
        """Запись строки в файл"""
        line = self._format_line(data)
        
        with open(file_path, 'r+') as f:
            f.seek(line_num * 501)
            f.write(line)
    
    # ЗАДАНИЕ 6. Удаление продажи (метод "мягкого" удаления)
    def revert_sale(self, sales_number: str) -> Car:
        """
        Отмена продажи автомобиля.
        
        Алгоритм (мягкое удаление):
        1. Найти продажу по номеру в индексе sales_by_number_index.txt
        2. Прочитать данные о продаже
        3. Найти автомобиль по VIN из продажи
        4. Обновить статус автомобиля на 'available'
        5. Пометить запись о продаже как удаленную (записать пустую строку)
        6. Удалить запись из индексов продаж
        
        Возвращает обновленный объект Car.
        """
        print(f"\n=== Отмена продажи ===")
        print(f"Номер продажи для отмены: {sales_number}")
        
        car_path = os.path.join(self.root_directory_path, "cars.txt")
        sales_path = os.path.join(self.root_directory_path, "sales.txt")
        
        # 1. Найти продажу по номеру в индексе
        print("1. Ищем продажу по номеру в индексе sales_by_number_index.txt")
        sale_line_num = self._find_in_index(self.sales_by_number_index, sales_number)
        
        if sale_line_num is None:
            raise ValueError(f"Продажа с номером {sales_number} не найдена")
        
        print(f"   Продажа найдена в строке: {sale_line_num}")
        
        # 2. Прочитать данные о продаже
        print("2. Читаем данные о продаже из файла sales.txt")
        sales_data = self._read_line(sales_path, sale_line_num)
        
        if not sales_data:
            raise ValueError(f"Не удалось прочитать данные о продаже с номером {sales_number}")
        
        vin = sales_data['car_vin']
        print(f"   Данные о продаже прочитаны:")
        print(f"     VIN автомобиля: {vin}")
        print(f"     Номер продажи: {sales_data.get('sales_number')}")
        print(f"     Дата продажи: {sales_data.get('sales_date')}")
        print(f"     Стоимость: {sales_data.get('cost')}")
        
        # 3. Найти автомобиль по VIN
        print(f"\n3. Ищем автомобиль по VIN {vin} в индексе cars_index.txt")
        car_line_num = self._find_in_index(self.cars_index, vin)
        
        if car_line_num is None:
            raise ValueError(f"Автомобиль с VIN {vin} не найден")
        
        print(f"   Автомобиль найден в строке: {car_line_num}")
        
        # Читаем данные автомобиля
        car_data = self._read_line(car_path, car_line_num)
        if not car_data:
            raise ValueError(f"Не удалось прочитать данные автомобиля с VIN {vin}")
        
        print(f"   Данные автомобиля прочитаны:")
        print(f"     Текущий статус: {car_data['status']}")
        
        # 4. Обновить статус автомобиля на 'available'
        print(f"\n4. Обновляем статус автомобиля с '{car_data['status']}' на 'available'")
        car_data['status'] = CarStatus.available.value
        
        # Записываем обновленные данные автомобиля
        self._write_line(car_path, car_line_num, car_data)
        print(f"   Статус автомобиля обновлен в файле cars.txt (строка {car_line_num})")
        
        # 5. Пометить запись о продаже как удаленную (мягкое удаление)
        print(f"\n5. Помечаем запись о продаже как удаленную")
        print(f"   Записываем пустую строку в файл sales.txt (строка {sale_line_num})")
        
        with open(sales_path, 'r+') as f:
            f.seek(sale_line_num * 501)
            f.write(' ' * 500 + '\n')  # Записываем строку из пробелов
        
        print(f"   Запись о продаже помечена как удаленная")
        
        # 6. Удалить запись из индексов продаж
        print(f"\n6. Удаляем запись из индексов продаж")
        
        # Удаляем из индекса продаж по VIN (sales_index.txt)
        if self._remove_from_index(self.sales_index, vin):
            print(f"   Запись удалена из индекса sales_index.txt (VIN: {vin})")
        else:
            print(f"   Запись не найдена в индексе sales_index.txt")
        
        # Удаляем из индекса продаж по номеру (sales_by_number_index.txt)
        if self._remove_from_index(self.sales_by_number_index, sales_number):
            print(f"   Запись удалена из индекса sales_by_number_index.txt (номер: {sales_number})")
        else:
            print(f"   Запись не найдена в индексе sales_by_number_index.txt")
        
        # Сохраняем обновленные индексы
        self._save_sorted_index("sales_index.txt", self.sales_index)
        self._save_sorted_index("sales_by_number_index.txt", self.sales_by_number_index)
        print(f"   Обновленные индексы сохранены в файлы")
        
        # Создаем и возвращаем обновленный объект Car
        print(f"\n7. Создаем обновленный объект Car")
        updated_car = Car(
            vin=car_data['vin'],
            model=int(car_data['model']),
            price=Decimal(car_data['price']),
            date_start=datetime.fromisoformat(car_data['date_start']),
            status=CarStatus(car_data['status'])
        )
        
        print(f"   Объект Car успешно создан")
        print(f"     Новый статус: {updated_car.status}")
        print(f"=== Отмена продажи завершена успешно ===")
        
        return updated_car